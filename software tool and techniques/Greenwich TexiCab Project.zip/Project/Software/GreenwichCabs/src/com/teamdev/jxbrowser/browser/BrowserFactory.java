/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.teamdev.jxbrowser.browser;

/**
 *
 * @author Abid
 */
public class BrowserFactory {

    public static Browser createBrowser() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
